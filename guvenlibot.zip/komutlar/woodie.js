const Discord = require('discord.js');


exports.run = function(client, message) {
 
    const embed = new Discord.RichEmbed()
        .setDescription("**GÜVENLİ BOT**")
        .setImage("")
        .setThumbnail("")
        .setColor(0x00AE86)
        .addField("Cinsi", "Lutino Muhabbet Kuşu", true)
        .addField("Özellikleri", `
        *Sapsarı Mükemmel Tüyleri Var
   *Hiç susmuyor :smile:
   `, true)

   message.channel.send(embed)
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'GÜVENLİ-BOT',
  description: 'GÜVENLİ BOT hakkında bilgi verir',
  usage: 'GÜVENLİ-BOT'
};